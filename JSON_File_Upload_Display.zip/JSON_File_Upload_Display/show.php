<?php
include('db.php');

if(!isset($_SESSION['IS_LOGIN'])){
	header('location:index.php');
	die();
}
echo "<br><br><center>Welcome ".$_SESSION['UNAME']."</center>";



?>
<!DOCTYPE html>
  <html lang="en">
    <head>
      <link rel="stylesheet" href="style.css">
      <title>Upload JSON file</title>
      <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
      <script src="main.js"></script>
    </head>
    <body>
      <div class="container">

<br/>

<a  style="margin:1030px;" href="dashboard.php">back</a><br><br>
<a  style="margin:1030px;" href="logout.php">Logout</a>
<?php
$conn = mysqli_connect('localhost', 'root', '', 'financepeer');
$sql = "SELECT * FROM student_data";
$result = mysqli_query($conn, $sql);

$files = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<table>
  <thead>
  <p style="background-color:#19af79;color:white;padding:10px;">Student Data</p>
 
  <th>Student ID</th>
  <th>Student Name</th>

      <th>Student Gender</th>
    <th>Student Age</th>
  </thead>
  <tbody>
    <?php foreach ($files as $file): ?>
      <tr>
      <td><?php echo $file['s_id']; ?></td>

      <td><?php echo $file['s_name']; ?></td>

      <td><?php echo $file['s_gender']; ?></td>

      <td><?php echo $file['s_age']; ?></td>
      
      </tr>
    <?php endforeach;?>

  </tbody>
  </table>
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
      <script src="main.js"></script>
    </body>
  </html>