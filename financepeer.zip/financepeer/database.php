<?php
$conn = mysqli_connect('localhost', 'root', '', 'financepeer');


if (isset($_POST['save'])) { 
    $filename = $_FILES['myfile']['name'];
	
	
    $file_path = 'uploads/' . $filename;

    $extension = pathinfo($filename, PATHINFO_EXTENSION);

    $file = $_FILES['myfile']['tmp_name'];
    $size = $_FILES['myfile']['size'];

    if (!in_array($extension, ['json'])) {
        echo "<div class='error'>Upload only .json file</div>";

    } elseif ($_FILES['myfile']['size'] > 10000000) { 
        echo "<div class='error'>File exceeded max size</div>";

    } else 
    {
        $store=file_get_contents($file);
        $data = json_decode($store, true);
        $s_id = $data['s_id'];
        $s_name = $data['s_name'];
        $s_gender = $data['s_gender'];
        $s_age = $data['s_age'];
            $sql = "INSERT INTO  student_data(s_id,s_name,s_gender,s_age) VALUES ('$s_id','$s_name','$s_gender','$s_age')";
            if (mysqli_query($conn, $sql)) 
			{
    
                echo "<div class='success'>✅Data converted and saved to database</div>";
                
            }
             
            else 
            {

                echo "<div class='error'>Failed to record</div>";
            }
        
    }

}

?>