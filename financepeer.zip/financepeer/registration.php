
<!DOCTYPE html>  
 <html>  
      <head>  
           <title>Login</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
      </head>  
      <body>  
	  <br /><br />  
           <div class="container" style="width:500px;">  
               
                <br />  

<form method="post" >
<table>
		<tr>
		<h1>&nbsp;&nbsp;&nbsp;&nbsp;Registration</h1><br>

			<td><br>Name</td>
			<td><br><input type="text" name="name" required class="form-control"/></td>
		</tr>
		<tr>
			<td><br>Username</td>
			<td><br><input type="text" name="username" required class="form-control"/></td>
		</tr>
		<tr>
			<td><br>Password</td>
			<td><br><input type="password" name="password" required class="form-control"/></td>
		</tr>
		<tr>
			<td></td>
			<td><br><input type="submit" name="submit"  class="btn btn-info"/></td>
			
<?php
include('db.php');
if(isset($_SESSION['IS_LOGIN'])){
	header('location:dashboard.php');
	die();
}
if(isset($_POST['submit'])){
	$name=$_POST['name'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	
	if(mysqli_num_rows(mysqli_query($con,"select * from user where username='$username'"))>0){
		echo "Userame already present";
	}else{
		$password=password_hash($password,PASSWORD_DEFAULT);
		mysqli_query($con,"insert into user(name,username,password) values('$name','$username','$password')");
		echo "Thank you. Registered successfully!";
	}
	
}
?>
			<p align="center"><a href="index.php">Login? </a></p>  
		</tr>
	</table>
</form>	