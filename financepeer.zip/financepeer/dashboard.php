<?php
include('db.php');

if(!isset($_SESSION['IS_LOGIN'])){
	header('location:index.php');
	die();
}
echo "<br><br><center>Welcome ".$_SESSION['UNAME']."</center>";



?>
  <!DOCTYPE html>
  <html lang="en">
    <head>
      <link rel="stylesheet" href="style.css">
      <title>Upload JSON file</title>
      <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
      <script src="main.js"></script>
    </head>
    <body>
      <div class="container">

<br/>

<a  style="margin:1030px;" href="logout.php">Logout</a>

<div class="row">
        <div class="log">
        
        <form enctype="multipart/form-data" action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
          <p style="background-color:#19af79;color:white;padding:10px;">Upload JSON file</p>
          <?php include 'database.php';?>
		  <div class="file-upload-wrapper" data-text="Choose file">
            <input type="file" name="myfile" class="file-upload-field" value="" required > <br></div>
            <br><br> <p>&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;* All fields are mandatory</p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <button type="submit" name="save" id="btn"> Save</button>
          </form>
          <a style="margin:230px;"href="show.php">Display data</a>
        </div>
      </div>
</div>

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
      <script src="main.js"></script>
    </body>
  </html>